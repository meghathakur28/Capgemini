﻿using QuickMart;
public class Program
{
    public static void Main(string[] args)
    {
        SaleTransactionBL saleTransactionBL = new SaleTransactionBL();
        saleTransactionBL.Menu();
    }
}
