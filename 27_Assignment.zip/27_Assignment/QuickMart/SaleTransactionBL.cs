using System;
namespace QuickMart
{
       public class SaleTransactionBL:SaleTransaction
    {
        static SaleTransaction LastTransaction;
        static bool HasLastTransaction = false;

        public void Menu()
        {
            int choice = 0;
            while (choice != 4)
            {
                Console.WriteLine("----- Sale Transaction Menu -----");
                Console.WriteLine("1. Create new Transaction");
                Console.WriteLine("2. View Last  Transaction");
                Console.WriteLine("3. Calculate Profit/Loss ");
                Console.WriteLine("4. Exit");
                Console.WriteLine("Select an option: ");
                choice = Int32.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        RecordSaleTransaction();
                        break;
                    case 2:
                        ViewLastSaleTransaction();
                        break;
                    case 3:
                        CalculateProfitOrLoss();
                        break;

                    case 4:
                        Console.WriteLine("Thankyou Application closed normally");
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please select a valid option.");
                        Menu();
                        break;
                }
            }
        }

        public void RecordSaleTransaction()
        {
            SaleTransaction transaction = new SaleTransaction();
            Console.Write("Enter Invoice No: ");
            transaction.InvoiceNo = Console.ReadLine();
            Console.Write("Enter Customer Name: ");
            transaction.CustomerName = Console.ReadLine();
            Console.Write("Enter Item Sold: ");
            transaction.ItemSold = Console.ReadLine();
            Console.Write("Enter Quantity: ");
            transaction.Quantity = int.Parse(Console.ReadLine());
            Console.Write("Enter Purchase Amount: ");
            transaction.PurchaseAmount = decimal.Parse(Console.ReadLine());
            Console.Write("Enter Selling Amount: ");
            transaction.SellingAmount = decimal.Parse(Console.ReadLine());
            LastTransaction = transaction;
            HasLastTransaction = true;
            CalculateProfitOrLoss();
            Console.WriteLine("Transaction saved successfully!");
            Console.WriteLine("Status: "+transaction.ProfitOrLossStatus);
            Console.WriteLine("Profit/Loss Amount: "+transaction.ProfitOrLossAmount);
            Console.WriteLine("Profit Margin: "+ transaction.ProfitMarginPercent);
        }
        public void ViewLastSaleTransaction()
        {
            if (!HasLastTransaction)
            {
                Console.WriteLine("No transaction available. Please create a new transaction");
                return;
            }
            Console.WriteLine("----- Last Sale Transaction Details -----");
            Console.WriteLine($"Invoice No: {LastTransaction.InvoiceNo}");
            Console.WriteLine($"Customer Name: {LastTransaction.CustomerName}");
            Console.WriteLine($"Item Sold: {LastTransaction.ItemSold}");
            Console.WriteLine($"Quantity: {LastTransaction.Quantity}");
            Console.WriteLine($"Purchase Amount: {LastTransaction.PurchaseAmount}");
            Console.WriteLine($"Selling Amount: {LastTransaction.SellingAmount}");
            Console.WriteLine($"Profit/Loss Status: {LastTransaction.ProfitOrLossStatus}");
            Console.WriteLine($"Profit/Loss Amount: {LastTransaction.ProfitOrLossAmount}");
            Console.WriteLine($"Profit Margin Percent: {LastTransaction.ProfitMarginPercent}%");
        }
        public void CalculateProfitOrLoss()
        {
            if (!HasLastTransaction)
            {
                Console.WriteLine("No transaction available. Please create a new transaction first.");
                return;
            }
            if (LastTransaction.SellingAmount>LastTransaction.PurchaseAmount)
            {
                LastTransaction.ProfitOrLossStatus = "Profit";
                LastTransaction.ProfitOrLossAmount = Math.Round(LastTransaction.SellingAmount - LastTransaction.PurchaseAmount,2);
            }
            else if (LastTransaction.SellingAmount < LastTransaction.PurchaseAmount)
            {
                LastTransaction.ProfitOrLossStatus = "Loss";
                LastTransaction.ProfitOrLossAmount = Math.Round(LastTransaction.PurchaseAmount - LastTransaction.SellingAmount,2);
            }
            else
            {
                LastTransaction.ProfitOrLossStatus = "Break-even";
                LastTransaction.ProfitOrLossAmount = 0;
            }
            LastTransaction.ProfitMarginPercent = Math.Round(LastTransaction.ProfitOrLossAmount / LastTransaction.PurchaseAmount * 100,2);
            
        }
    }

}