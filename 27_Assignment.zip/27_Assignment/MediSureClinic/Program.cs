﻿using MediSureClinic;
public class Program
{
    public static void Main(string[] args)
    {
        PatientBillBL billBL = new PatientBillBL();
        billBL.Menu();
    }
}
