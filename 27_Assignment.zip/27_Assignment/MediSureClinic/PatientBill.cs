using System;

namespace MediSureClinic
{
    public class PatientBill
    {
        public string BillId { get; set; }
        public string PatientName { get; set; }
        public bool HasInsurance { get; set; }
        decimal consulationFee;
        public decimal ConsulationFee
        {
            get
            {
                return consulationFee;
            }
            set
            {
                consulationFee = value;
            }
        }
        decimal labCharges;
        public decimal LabCharges
        {
            get
            {
                return labCharges;
            }
            set
            {
                labCharges = value;

            }
        }

        public decimal MedicineCharges { get; set; }
        public decimal GrossAmount
        {
            get
            {
                return Math.Round(ConsulationFee + LabCharges + MedicineCharges, 2);
            }
        }
        public decimal DiscountAmount
        {
            get
            {
                if (!HasInsurance)
                {
                    return 0;
                }
                return Math.Round(GrossAmount * 10 / 100, 2);
            }
        }
        public decimal FinalPayable
        {
            get
            {
                return Math.Round(GrossAmount - DiscountAmount, 2);
            }
        }
    }
}
