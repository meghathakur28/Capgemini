using System;

namespace MediSureClinic
{
    public class PatientBillBL : PatientBill
    {
        static PatientBill LastBill;
        static bool HasLastBill = false;
        public void Menu()
        {
            int choice = 0;
            while (choice != 4)
            {
                System.Console.WriteLine("--- Patient Bill Management ---");
                System.Console.WriteLine("Enter the value based on the operation you want to perform:");
                System.Console.WriteLine("1) Create New Bill (Enter the Patient Details");
                System.Console.WriteLine("2) View Last Bill");
                System.Console.WriteLine("3) Clear Last Bill");
                System.Console.WriteLine("4) Exit");
                System.Console.WriteLine("Enter you choice: ");
                choice = Int32.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        {
                            Create();
                            break;
                        }

                    case 2:
                        {
                            View();
                            break;
                        }
                    case 3:
                        {
                            Clear();
                            break;
                        }
                    case 4:
                        {
                            Console.WriteLine("Thankyou. Application closed normally");
                            break;
                        }
                }
            }
        }
        public void Create()
        {
            PatientBill bill = new PatientBill();
            Console.WriteLine("Enter the BillID: ");
            bill.BillId = Console.ReadLine();
            Console.WriteLine("Enter the patient Name: ");
            bill.PatientName = Console.ReadLine();
            Console.WriteLine("Enter if you have insurance (True/False)");
            bill.HasInsurance = bool.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Consultation Fee: ");
            bill.ConsulationFee = decimal.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Lab Charges");
            bill.LabCharges = decimal.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Medicine Charges");
            bill.MedicineCharges = decimal.Parse(Console.ReadLine());
            HasLastBill = true;
            LastBill = bill;
            System.Console.WriteLine("Bill Created Successfully.\n");
            System.Console.WriteLine("Gross Amount: " + bill.GrossAmount);
            System.Console.WriteLine("Discount Amount: " + bill.DiscountAmount);
            System.Console.WriteLine("Final Amount: " + bill.FinalPayable);


        }
        public void View()
        {
            if (!HasLastBill)
            {
                Console.WriteLine("No bill available. Please create a new bill first");
                return;
            }
            System.Console.WriteLine("BillID: " + BillId);
            System.Console.WriteLine("Patient: " + PatientName);
            System.Console.WriteLine("Insured: " + HasInsurance);
            System.Console.WriteLine("ConsulationFee: " + ConsulationFee);
            System.Console.WriteLine("Lab Charges: " + LabCharges);
            System.Console.WriteLine("Medicine Charges: " + MedicineCharges);
            System.Console.WriteLine("Gross Amount: " + GrossAmount);
            System.Console.WriteLine("Discount Amount: " + DiscountAmount);
            System.Console.WriteLine("Final Payable: " + FinalPayable);

        }
        public void Clear()
        {
            HasLastBill = false;
            LastBill = null;
            Console.WriteLine("Last bill cleared.");
        }


    }
}
