using System;
namespace HasinaCabs
{
    public class Cab
    {
        public string BookingID { get; set; }
        public string CabType { get; set;}
        public double Distance { get; set; }
        public int WaitingTime { get; set; }

    }
}
