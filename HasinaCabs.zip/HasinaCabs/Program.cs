﻿// See https://aka.ms/new-console-template for more information
using HasinaCabs;
public class Program
{
    public static void Main(string[] args)
    {
        CabDetails cabDetailsObj = new CabDetails();
        Console.WriteLine("Enter the booking id");
        string bookingID = Console.ReadLine();
        cabDetailsObj.BookingID = bookingID;

        if(!cabDetailsObj.ValidateBookingID())
        {
            Console.WriteLine("Invalid Booking ID");
            return;
        }

        Console.WriteLine("Enter the cab type");
        cabDetailsObj.CabType = Console.ReadLine();

        Console.WriteLine("Enter the distance in km");
        cabDetailsObj.Distance = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Enter the waiting time in minutes");
        cabDetailsObj.WaitingTime = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("The Fare Amount is: " + cabDetailsObj.CalculateFareAmount());
    }
}
