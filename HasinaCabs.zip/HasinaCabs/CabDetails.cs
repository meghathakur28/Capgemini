using System;
namespace HasinaCabs
{
    public class CabDetails:Cab
    {
        bool ValidateAC(string bookingID)
        {
            int index = bookingID.IndexOf('@');
            //int flag = 0;
            //for(int i=0;i<index;i++)
            //{
            //    if (bookingID[i]=='A'|| bookingID[i]=='C')
            //    {
            //        flag++;
            //    }
            //}
            //if(flag >=2)
            //{
            //    return true;
            //}
            //return false;

            if(bookingID[0]=='A' && bookingID[1]=='C')
            {
                return true;
            }
            return false;

        }
        bool Validate3Digit(string bookingID)
        {
            int length = bookingID.Length;
            int indx = bookingID.IndexOf('@');
            if(length-indx -1 == 3)
            {
                return true;
            }
            return false;

        }
        public bool ValidateBookingID()
        {
            if(BookingID.Length ==6 && ValidateAC(BookingID) && Validate3Digit(BookingID))
            {
                return true;
            }
            return false;
        }

        public double CalculateFareAmount()
        {
            int pricePerKm;
            double WaitingCharge = Math.Sqrt(WaitingTime);
            if (CabType == "Hachback") pricePerKm = 10;
            else if (CabType == "Sedan") pricePerKm = 20;
            else if (CabType == "SUV") pricePerKm = 30;
            else pricePerKm = 0;
            double fare = Distance * pricePerKm + WaitingCharge;
            return Math.Round(fare,2);

        }
    }
}