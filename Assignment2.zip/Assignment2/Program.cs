﻿// See https://aka.ms/new-console-template for more information
using Assignment2;
//AreaOfCircle.Area();
//ConvertFeetToCentimeters.Convert();
//HeightCategory.CheckHeight();
//ConditionalLogic.Conditional();
//PostiveNumberSum.SumPositiveNumbers();
//MultiplicationTable.Table();
//ArrayString.SumString();
//GCD.ComputeGCD();
//BankAccount.Account();
//ObjectArray.MixedArray();
//SummaryArray.Summary();
SecToMin.ConvertSecToMin();
