using System;
namespace CourseRegistrationFee
{
    public class Student
    {
        
        public int StudentID { get; set; }
        public string Name { get; set; }
        public string Course { get; set; }
        public int Semester { get; set; }
        public double CGPA { get; set; }
        public  double BaseFee { get; set; }
        public double Fee {  get; set; }
    }
}