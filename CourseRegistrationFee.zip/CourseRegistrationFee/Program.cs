﻿using CourseRegistrationFee;
public class Program
{
    public static void Main(string[] args)
    {
        StudentBL studentBL = new StudentBL();
        studentBL.Menu();
    }
}
