using System;
namespace CourseRegistrationFee
{
    public class StudentBL:Student
    {
        public List<Student> studentsList;
        public StudentBL()
        {
            studentsList = new List<Student>();
        }
        public void Menu()
        {
            int choice = 0;
            while (choice != 5)
            {
                Console.WriteLine("1. Register Student");
                Console.WriteLine("2. View All Students");
                Console.WriteLine("3.View Fee Details");
                Console.WriteLine("4. Total Fee Collected");
                Console.WriteLine("5. Exit");
                choice = Int32.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        {
                            RegisterStudent();
                            break;
                        }
                    case 2:
                        {
                            View();
                            break;
                        }
                    case 3:
                        {
                            ViewFeeDetails();
                            break;
                        }
                    case 4:
                        {
                            TotalFeeCollected();
                            break;
                        }
                    case 5:
                        {
                            Console.WriteLine("Thankyou for visiting");
                            break;
                        }
                }
            }

        }
        protected void RegisterStudent()
        {
            Student student = new Student();
            Console.WriteLine("Enter the details: ");
            Console.WriteLine("Enter Student ID: ");
            student.StudentID = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Enter Student Name: ");
            student.Name = Console.ReadLine();
            Console.WriteLine("Enter Course Name: ");
            student.Course = Console.ReadLine();
            Console.WriteLine("Enter Semester: ");
            int semester = Int32.Parse(Console.ReadLine());
            try
            {
                if (semester > 8 || semester <= 0)
                {
                    throw new InvalidSemesterException("Invalid Semester (Semester should be between 1 and 8");
                }
                else
                {
                    student.Semester = semester;
                }
            }
            catch(InvalidSemesterException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.WriteLine("Enter CGPA: ");
            student.CGPA = Double.Parse(Console.ReadLine());
            Console.WriteLine("Enter Base Fee: ");
            student.BaseFee = Double.Parse(Console.ReadLine());
            double fee = student.BaseFee;
            if(student.CGPA>=8.5)
            {
                fee -= fee * 25 / 100;

            }
            if(student.Semester>=6)
            {
                fee += fee * 20 / 100;
            }
            student.Fee = fee;
            studentsList.Add(student);
            Console.WriteLine("Student Registered Successfully");
        }
        protected void View()
        {
            Console.WriteLine("Student Details:");
            int i = 0;
            foreach(var st in studentsList)
            {
                Console.WriteLine("\n" + (i + 1) + "\na). Name: " + st.StudentID + "\nb).Name: " + st.Name + "\nc). Course: " + st.Course + "\nd). Semester: " + st.Semester + "\ne). BaseFee: " + st.BaseFee+"\nf). Fee:"+st.Fee);
                i++;
            }
        }
        protected void ViewFeeDetails()
        {
            Console.WriteLine("Enter you choice:");
            Console.WriteLine("1. Fee Details of all Students");
            Console.WriteLine("2. View by Student ID");
            Console.WriteLine("3. View by Name");
            Console.WriteLine("4. Exit");
            int choice = 0;
            while(choice!=4)
            {
                Console.WriteLine("Enter: ");
                choice = Int32.Parse(Console.ReadLine());
                switch(choice)
                {
                    case 1:
                        {
                            foreach(var i in studentsList)
                            {
                                Console.WriteLine("ID: " + i.StudentID + " = " + i.Fee);
                            }
                            break;
                        }
                    case 2:
                        {
                            Console.WriteLine("Enter the Student ID: ");
                            int id = Int32.Parse(Console.ReadLine());
                            Student stObj = studentsList.Find(d => d.StudentID == id);
                            if(stObj!=null)
                            {
                                Console.WriteLine("ID: " + stObj.StudentID + ", Name: " + stObj.Name + " Fee: " + stObj.Fee);
                                Console.WriteLine("Details: ");
                                Console.WriteLine("Base Fee: " + stObj.BaseFee);
                                if (stObj.Semester>=6)
                                {
                                    Console.WriteLine("20% exam fee");
                                }
                                if(stObj.CGPA>=8.5)
                                {
                                    Console.WriteLine("Discount : 25%");
                                }
                            }
                            break;
                        }
                    case 3:
                        {
                            Console.WriteLine("Enter the Student Name: ");
                            string name = Console.ReadLine();
 
                            Student stObj = studentsList.Find(d => d.Name == name);
                            if (stObj != null)
                            {
                                Console.WriteLine("ID: " + stObj.StudentID + ", Name: " + stObj.Name + " Fee: " + stObj.Fee);
                                Console.WriteLine("Details: ");
                                Console.WriteLine("Base Fee: " + stObj.BaseFee);
                                if (stObj.Semester >= 6)
                                {
                                    Console.WriteLine("20% exam fee");
                                }
                                if (stObj.CGPA >= 8.5)
                                {
                                    Console.WriteLine("Discount : 25%");
                                }
                            }
                            break;
                        }
                    case 4:
                        {
                            break;
                        }

                }
            }

        }

        protected void TotalFeeCollected()
        {
            double sum = 0;
            foreach(var i in studentsList)
            {
                sum += i.Fee;
            }
            Console.WriteLine("Total Fee: " + Math.Round(sum, 2));
        }

    }
}