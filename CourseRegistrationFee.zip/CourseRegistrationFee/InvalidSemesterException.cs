using System;
namespace CourseRegistrationFee
{
    public class InvalidSemesterException : Exception
    {
        public InvalidSemesterException() { }
        public InvalidSemesterException(string message) : base(message)
        {
        }
    }
}