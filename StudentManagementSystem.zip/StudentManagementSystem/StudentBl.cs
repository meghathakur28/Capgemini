
using System;
namespace StudentManagementSystem
{
    public class StudentBl
    {
        Student sObj = null;
        public StudentBl()
        {
            sObj = new Student();
        }
        public void AcceptStudentDetails()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Student Management System");
            Console.WriteLine("=============================================");

            try
            {

                Console.WriteLine("Enter the rollNo: ");
                sObj.RollNo = Int32.Parse(Console.ReadLine());

                Console.WriteLine("Enter the Name: ");
                sObj.Name = Console.ReadLine();

                Console.WriteLine("Enter the Address: ");
                sObj.Addr = Console.ReadLine();

                Console.WriteLine("Enter the Physics marks: ");
                sObj.Phy = Int32.Parse(Console.ReadLine());

                Console.WriteLine("Enter the Chemistry marks: ");
                sObj.Chem = Int32.Parse(Console.ReadLine());

                Console.WriteLine("Enter the Maths marks: ");
                sObj.Maths = Int32.Parse(Console.ReadLine());
            }
            catch (InvalidMarksException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ForegroundColor = ConsoleColor.Red;
        }
        public int CalcTotal()
        {
            sObj.Total = sObj.Phy + sObj.Maths + sObj.Chem;
            return sObj.Total;
        }
        public float CalcAvg()
        {
            sObj.Per = sObj.Total / 3;
            return sObj.Per;
        }
        public void CalcResult(out int myTotal,out float myPerc)
        {
            myTotal = sObj.Phy + sObj.Maths + sObj.Chem;
            myPerc = sObj.Total/3;
        }
    }
}