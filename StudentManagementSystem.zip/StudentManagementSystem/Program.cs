﻿// See https://aka.ms/new-console-template for more information
using StudentManagementSystem;

StudentBl sblobj = new StudentBl();



sblobj.AcceptStudentDetails();
int t;
float p;
Console.WriteLine(sblobj.CalcResult(out t, out p));
Console.WriteLine("Total Amount: {0}",sblobj.CalcTotal());
Console.WriteLine("Percentage: {0}",sblobj.CalcAvg());
