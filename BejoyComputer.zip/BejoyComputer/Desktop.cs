using System;
namespace BejoyComputer
{ 
    public class Desktop: Computer
    {
        public int MonitorSize {  get; set; }
        public int PowerSupplyVolt {  get; set; }
        public int MonitorPrice = 250;
        public int PowerSupplyVoltPrice = 20;
        public int ProcessorCost()
        {
            if (Processor == "i3")
            {
                return 1500;
            }
            else if (Processor == "i5")
            {
                return 3000;
            }
            else if (Processor == "i7")
            {
                return 4500;
            }
            else
                return 0;
        }
        public double DesktopPriceCalculation()
        {
            return (ProcessorCost() + (RamSize * RamPrice) + (HardDiskSize * HardDiskPrice) + (GraphicCard * GraphicCardPrice) + (MonitorSize * MonitorPrice) + (PowerSupplyVolt * PowerSupplyVoltPrice));
        }
    }
}
