﻿// See https://aka.ms/new-console-template for more information
namespace BejoyComputer;

public class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("1. Desktop\n 2. Laptop");
        Console.WriteLine("Choose the option");
        int choice = Int32.Parse(Console.ReadLine());

        switch (choice)
        {
            case 1:
                Desktop dk = new Desktop();
                Console.WriteLine("Enter the processor");
                dk.Processor = Console.ReadLine();

                Console.WriteLine("Enter the ram size");
                dk.RamSize = Int32.Parse(Console.ReadLine());

                Console.WriteLine("Enter the hard disk size");
                dk.HardDiskSize = Int32.Parse(Console.ReadLine());

                Console.WriteLine("Enter the graphic card size");
                dk.GraphicCard = Int32.Parse(Console.ReadLine());

                Console.WriteLine("Enter the monitor size");
                dk.MonitorSize = Int32.Parse(Console.ReadLine());

                Console.WriteLine("Enter the power supply volt");
                dk.PowerSupplyVolt = Int32.Parse(Console.ReadLine());

                Console.WriteLine("Desktop price is "+dk.DesktopPriceCalculation());
                break;


            case 2:
                Laptop lp = new Laptop();
                Console.WriteLine("Enter the processor");
                lp.Processor = Console.ReadLine();

                Console.WriteLine("Enter the ram size");
                lp.RamSize = Int32.Parse(Console.ReadLine());

                Console.WriteLine("Enter the hard disk size");
                lp.HardDiskSize = Int32.Parse(Console.ReadLine());

                Console.WriteLine("Enter the graphic card size");
                lp.GraphicCard = Int32.Parse(Console.ReadLine());

                Console.WriteLine("Enter the display size");
                lp.DisplaySize = Int32.Parse(Console.ReadLine());

                Console.WriteLine("Enter the battery volt");
                lp.BatteryVolt = Int32.Parse(Console.ReadLine());

                Console.WriteLine("Desktop price is " + lp.LaptopPriceCalculation());
                break;

        }
    }
}
