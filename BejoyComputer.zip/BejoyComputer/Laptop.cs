using System;
namespace BejoyComputer
{ 
    public class Laptop: Computer
    {
        public int DisplaySize {  get; set; }
        public int BatteryVolt { get; set; }
        public int DisplayPrice = 250;
        public int BatteryVoltPrice = 20;
        public int ProcessorCost()
        {
            if (Processor == "i3")
            {
                return 2500;
            }
            else if (Processor == "i5")
            {
                return 5000;
            }
            else if (Processor == "i7")
            {
                return 6500;
            }
            else return 0;
        }
        public double LaptopPriceCalculation()
        {
            return (ProcessorCost() + (RamSize * RamPrice) + (HardDiskSize * HardDiskPrice) + (GraphicCard * GraphicCardPrice) + (DisplaySize * DisplayPrice) + (BatteryVolt * BatteryVoltPrice));
        }
    }
}
