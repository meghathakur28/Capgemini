using System;
namespace BejoyComputer
{
    public class Computer
    {
        public string Processor { get; set; }
        public int RamSize { get; set; }
        public int HardDiskSize {  get; set; }
        public int GraphicCard {  get; set; }
        public int RamPrice = 200;
        public int HardDiskPrice = 1500;
        public int GraphicCardPrice = 2500;

    }

}