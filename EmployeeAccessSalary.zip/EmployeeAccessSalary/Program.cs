﻿// See https://aka.ms/new-console-template for more information

using EmployeeAccessSalary;

EmployeesBL objBL = new EmployeesBL();
objBL.inputinfo();
objBL.displayinfo();