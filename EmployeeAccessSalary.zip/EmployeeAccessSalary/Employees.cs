using System;
namespace EmployeeAccessSalary
{
    public class Employees
    {
        int age;
        int department;
        public string emprole;
        public string empdep;
        int allo;
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public int Age
        {
            get
            {
                return age;
            }
            set
            {
                if (value >= 21)
                {
                    age = value;
                }
                else
                {
                    throw new Exception("Employee id not eligible");
                }
            }
        }
        public int Department {
            get
            {
                return department;
            }
            set
            {
                department = value;
            }
        }
        public void d() { 
        Console.WriteLine("Your department is: ");
            switch (department)
            {
                case 1:
                    Console.WriteLine("II");
                    empdep = "IT";
                    Console.WriteLine("Enter your Role Selection: \n 1) Developer \n2) Tester");
                     int role = Int32.Parse(Console.ReadLine());
                    switch (role)
                    {
                        case 1:
                            Console.WriteLine("Developer");
                            emprole = "Developer";
                            allo = 30;
                            break;

                        case 2:
                            Console.WriteLine("Tester");
                            emprole = "Tester";
                            allo = 25;
                            break;
                    }
                    break;
                case 2:
                    Console.WriteLine("HR");
                    empdep = "HR";
                    Console.WriteLine("Enter your Role Selection: \n 1) Recruiter \n2) Payroll");
                    role = Int32.Parse(Console.ReadLine());
                    switch (role)
                    {
                        case 1:
                            Console.WriteLine("Recruiter");
                            emprole = "Recruiter";
                            allo = 20;
                            break;

                        case 2:
                            Console.WriteLine("Payroll");
                            emprole = "Payroll";
                            allo = 22;
                            break;
                    }
                    break;
                case 3:
                    Console.WriteLine("Finance");
                    empdep = "Finance";
                    Console.WriteLine("Enter your Role Selection: \n 1) Accountant \n2)  Auditor");
                    role = Int32.Parse(Console.ReadLine());
                    switch(role){
                       case 1:
                            Console.WriteLine("Accountant");
                            emprole = "Accountant";
                            allo = 28;
                            break;

                        case 2:
                            Console.WriteLine("Auditor");
                            emprole = "Auditor";
                            allo = 26;
                            break;
                        }
                        break;

                    }
            }
        public double Salary {  get; set; }
        public double FinalSalary()
        {
            return Salary + (Salary * allo / 100);
        }



    }
}