using System;

namespace EmployeeAccessSalary
{
    public class EmployeesBL
    {
        Employees obj;
        public EmployeesBL()
        {
            obj = new Employees();
        }

        public void inputinfo()
        {
            Console.WriteLine("Enter the details");
            Console.WriteLine("==============================");

            Console.WriteLine("Enter your Employee ID: ");
            obj.EmpId = int.Parse(Console.ReadLine());  

            Console.WriteLine("Enter your Name: ");
            obj.EmpName = Console.ReadLine();            

            Console.WriteLine("Enter your Age: ");
            obj.Age = int.Parse(Console.ReadLine());     

            Console.WriteLine("Enter your Department 1 -> IT 2 -> HR 3 -> Finance: ");
            obj.Department = int.Parse(Console.ReadLine());

            obj.d();

            Console.WriteLine("Enter your Salary: ");
            obj.Salary = double.Parse(Console.ReadLine());
        }

        public double SalCal()
        {
            return obj.FinalSalary();
        }

        public string AccessLevel()
        {
            double finalSalary = SalCal();

            if (finalSalary >= 60000 && obj.empdep == "IT")
            {
                return "Admin Access";
            }
            else if (finalSalary >= 60000 && obj.empdep != "IT")
            {
                return "Manager Access";
            }
            else
            {
                return "Employee Access";
            }
        }

        public void displayinfo()
        {
            Console.WriteLine("Employee ID: " + obj.EmpId);
            Console.WriteLine("Name: " + obj.EmpName);
            Console.WriteLine("Department: " + obj.empdep);
            Console.WriteLine("Role: " + obj.emprole);
            Console.WriteLine("Basic Salary: " + obj.Salary);
            Console.WriteLine("Final Salary: " + SalCal());
            Console.WriteLine("Access Level: " + AccessLevel());
        }
    }
}

