using System;
namespace Week1Assignment;

public class EnumSwitch3
{
	public enum Day
	{
	      Monday,Tuesday,Wednesday,Thursday,Friday,Saturday
	}
	public static void Enums()
	{
		Console.WriteLine("Enter the day: ");
		string d = Console.ReadLine();

		Day day;
		if (Enum.TryParse(d, true, out day))
		{
			switch (day)
			{
				case Day.Monday:
					Console.WriteLine("Pizza");
					break;

				case Day.Tuesday:
					Console.WriteLine("Mackroni");
					break;
				case Day.Wednesday:
					Console.WriteLine("dosa");
					break;

				case Day.Thursday:
					Console.WriteLine("pasta");
					break;
				case Day.Friday:
					Console.WriteLine("burger");
					break;

				case Day.Saturday:
					Console.WriteLine("idle");
					break;
				default:
					Console.WriteLine("Wrong data");
					break;
			}
		}
		else
		{
			Console.WriteLine("Please enter the correct day");
		}

		}
}