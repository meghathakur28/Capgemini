using System;
namespace Week1Assignment;

public class BubbleSort
{
    public static void Sort()
    {
        int[] arr = new int[5];
        for(int i=0;i<5;i++)
        {
            arr[i] = Int32.Parse(Console.ReadLine());
        }
        Console.WriteLine("original array: ");
        for(int i=0;i<5;i++)
        {
            Console.Write(arr[i]);
        }
        Console.WriteLine(" ");
        for(int i=0;i<5-1;i++)
        {
            for(int j=0;j<5-1-i;j++)
            {
                if (arr[j] > arr[j+1])
                {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;  
                }
            }
        }
        Console.WriteLine("Sorted array: ");
        for(int i=0;i<5;i++)
        {
            Console.Write(arr[i]);
        }

    }
}
