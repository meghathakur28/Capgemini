using System;
namespace Week1Assignment;
public class TypeCasting { 
    public static void ArrayType()
    {
        Console.WriteLine("Enter the length of the first array: ");
        int n1 = Int32.Parse(Console.ReadLine());

        Console.WriteLine("Enter the length of the second array: ");
        int n2 = Int32.Parse(Console.ReadLine());

        double[] arr1 = new double[n1];
        double[] arr2 = new double[n2];

        Console.Write("Enter the values of the first array: ");
        for(int i=0;i<n1;i++)
        {
            arr1[i] = Double.Parse(Console.ReadLine());
        }
        Console.Write("Enter the values of the second array: ");
        for (int i = 0; i < n2; i++)
        {
            arr2[i] = Double.Parse(Console.ReadLine());
        }
        int[] result = new int[Math.Max(n1, n2)];
        Console.WriteLine("The resultant array: ");
        for (int i=0;i< Math.Max(n1,n2);i++)
        {
            if (i < n1 && i < n2)
            {
                result[i] = (int)(arr1[i] + arr2[i]);
            }
            else if(i<n1)
            {
                result[i] = (int)(arr1[i]);
            }
            else
            {
                result[i] = (int)(arr2[i]);
            }
                Console.Write(result[i]);
            Console.Write(" ");
        }

     


    }
}
