﻿// See https://aka.ms/new-console-template for more information
using Week1Assignment;
//BubbleSort.Sort();
//TypeCasting.ArrayType();
EnumSwitch3.Enums();