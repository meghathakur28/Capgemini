using System;
namespace CakeWorld
{
    public class Cake
    {
        int discount;
        string flavour;
        public string Flavour {
            get
            {
                return flavour;

            }
            set
            {
                flavour = value;
                if (value == "Chocolate") discount = 5;
                else if (value == "Vanilla") discount = 3;
                else if (value == "Red Velvet") discount = 10;
            }
        }
        public int QuantityInKg {  get; set; }
        public double PricePerKg {  get; set; }
        public int Discount { get { return discount; } }

        public bool CakeOrder()
        {
            if (Flavour=="Chocolate"||Flavour == "Red Velvet" || Flavour == "Vanilla")
            {
                if (QuantityInKg > 0)
                {
                    return true;
                }
                else throw new Exception("Quantity must be greater than zero");
            }
            else throw new Exception("Flavour not available \n Please select the available flavour");
        }
        public double CalculatePrice()
        {
            double totalprice =  QuantityInKg * PricePerKg;
            double discountedPrice = totalprice - (totalprice * Discount / 100);
            return discountedPrice;
        }
    }
}