﻿using CakeWorld;
public class Program
{
    public static void Main(string[] args)
    {
        Cake cObj = new Cake();
        Console.WriteLine("Enter the Flavour");
        cObj.Flavour = Console.ReadLine();

        Console.WriteLine("Enter the Quantity In Kg ");
        cObj.QuantityInKg = Int32.Parse(Console.ReadLine());

        Console.WriteLine("Enter the price Per Kg");
        cObj.PricePerKg = Int32.Parse(Console.ReadLine());

        cObj.CakeOrder();

        Console.WriteLine("Cake order was successful");
        Console.WriteLine("Prive after discount is" + cObj.CalculatePrice());

    }
}
