﻿// See https://aka.ms/new-console-template for more information
using CandyCraze;
public class Program
{
    int totalPrice;
    double discountPrice;
    public void calculateDiscountedPrice(Candy candy)
    {
        totalPrice = candy.Quantity * candy.PricePerPiece;
        discountPrice =  totalPrice - (totalPrice * candy.Discount / 100);
    }
    public int TotalPrice { get { return totalPrice; } }
    public double DiscountPrice {  get { return discountPrice; } }
    public static void Main(string[] args)
    {
        Candy cObj = new Candy();
        Program p = new Program();
        Console.WriteLine("Enter the flavour");
        cObj.Flavour = Console.ReadLine();

        Console.WriteLine("Enter the quantity");
        cObj.Quantity = Int32.Parse(Console.ReadLine());

        Console.WriteLine("Enter the price per piece");
        cObj.PricePerPiece = Int32.Parse(Console.ReadLine());

        if (cObj.ValidatecandyFlavour() == false)
        {
            Console.WriteLine("Invalid Flavour");
            return;
        }

        Console.WriteLine("Flavour: " + cObj.Flavour);
        Console.WriteLine("Price Per Piece: "+cObj.Quantity);
        Console.WriteLine("Quantity: "+cObj.PricePerPiece);
        p.calculateDiscountedPrice(cObj);
        Console.WriteLine("Total Price: "+p.TotalPrice);
        Console.WriteLine("Discount Price: " + p.DiscountPrice);
    }
}
