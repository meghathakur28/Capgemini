using System;
namespace CandyCraze
{
    public class Candy
    {
        double discount;
        string flavour;
        public string Flavour {
            get
            {
                return flavour;
            }
            set
            {
                flavour = value;
                if (value == "Strawberry")
                {
                    discount = 15;
                }
                else if( value =="Lemon")
                {
                    discount = 10;
                }
                else if(value =="Mint")
                {
                    discount = 20;
                }

            }
        }
        public int Quantity {  get; set; }
        public int PricePerPiece {  get; set; }
        public double Discount { get { return discount; } }

        public bool ValidatecandyFlavour()
        {
            if (Flavour == "Strawberry" || Flavour == "Lemon" || Flavour == "Mint")
            {
                return true;
            }
            else return false;
        }
    }
}