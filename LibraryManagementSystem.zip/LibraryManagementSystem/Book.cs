using System;
namespace LibraryManagementSystem
{
    public class Book
    {
        string title;
        string author;
        int numPages;
        DateTime duedate;
        DateTime returnedDate;
        public Book()
        {

        }
        public Book(string title, string author,int numPages,DateTime duedate, DateTime returnedDate)
        {
            this.title = title; 
            this.author = author;
            this.numPages = numPages;
            this.duedate = duedate;
            this.returnedDate = returnedDate;
        }
        public double AveragePagesReadPerDay(int daysToRead)
        {
            return (double) (numPages / daysToRead);
        }
        public double CalculateLateFee(double dailyLateFeerate)
        {
            TimeSpan daysleft = returnedDate - duedate;
            double lateFee = (double) (daysleft.Days * dailyLateFeerate);
                return lateFee;
        }
    }
}