﻿// See https://aka.ms/new-console-template for more information
using LibraryManagementSystem;
public class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter the title");
        string titlem = Console.ReadLine();

        Console.WriteLine("\nEnter the title");
        string authorm = Console.ReadLine();

        Console.WriteLine("\n Enter the number of pages");
        int numPagesm = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("\n Enter the due date");
        DateTime duedatem = Convert.ToDateTime(Console.ReadLine());

        Console.WriteLine("\n Enter the returned date");
        DateTime returnedDatem = Convert.ToDateTime(Console.ReadLine());

        Console.WriteLine("\n Enter the number of days to read the book");
        int daysToRead = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("\n Enter the daily late fee rate");
        double dailyLateFeerate = Convert.ToDouble(Console.ReadLine());

        Book bookObj = new Book(titlem,authorm,numPagesm,duedatem,returnedDatem);

        Console.WriteLine("\n Average pages read per day: " + bookObj.AveragePagesReadPerDay(daysToRead));
        Console.WriteLine("\n Late fee: " + bookObj.CalculateLateFee(dailyLateFeerate));
    }

}
