﻿using LPU_Common;
using LPU_Entity;
using LPU_Exception;
using LPU_DAL;
using System;
using System.Collections.Generic;
using System.Text;

namespace LPU_BL
{
    public class EmployeeBL : IEmployee<Employee>
    {
        EmployeeDAO empDAO;
        public EmployeeBL() { 
            empDAO = new EmployeeDAO();
        }
        public bool AddDetails(Employee obj)
        {
            try
            {
                return empDAO.AddDetails(obj);
        }
            catch(LPUException ex)
            {
                throw ex;
            }
            catch(Exception ex)
            {
                throw new Exception("Technical issue occured. Please contact to support team.", ex);
}
return false;
        }

        public bool DeleteDetails(int id)
        {
            try
            {
                return empDAO.DeleteDetails(id);
            }
            catch (LPUException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new Exception("Technical issue occured. Please contact to support team.", ex);
            }
        }

        public List<Employee> ShowAll()
        {
            try
            {
                return empDAO.ShowAll();
            }
            catch (LPUException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new Exception("Technical issue occured. Please contact to support team.", ex);
            }
        }

        public List<Employee> ShowAllEmployeeWithAgeAbove40()
        {
            try
            {
                return empDAO.ShowAllEmployeeWithAgeAbove40();
            }
            catch (Exception ex)
            {
                throw new Exception("Technical issue occured. Please contact to support team.", ex);
            }
        }

        public List<Employee> ShowAllFemaleEmployee()
        {
            try
            {
                return empDAO.ShowAllFemaleEmployee();
            }
            catch (Exception ex)
            {
                throw new Exception("Technical issue occured. Please contact to support team.", ex);
            }
        }

        public List<Employee> ShowAllMaleEmployee()
        {
            try
            {
                return empDAO.ShowAllMaleEmployee();

            }
            catch (Exception ex)
            {
                throw new Exception("Technical issue occured. Please contact to support team.", ex);
            }
        }

        public Employee ShowDetailsByID(int id)
        {
            try
            {
                return empDAO.ShowDetailsByID(id);
            }
            catch (LPUException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new Exception("Technical issue occured. Please contact to support team.", ex);
            }
        }

        public bool UpdateDetails(int id, Employee obj)
        {
            try
            {
                return empDAO.UpdateDetails(id, obj);
            }
            catch (LPUException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new Exception("Technical issue occured. Please contact to support team.", ex);
            }
        }
    }
}
