﻿using System;
using System.Diagnostics;
using LPU_Common;
using LPU_Entity;
using LPU_Exception;
namespace LPU_DAL
{
    public class StudentDAO : IStudentCRUD
    {
        static List<Student> studentList;

        GenericClass<float> genObj = null;
        public StudentDAO()
        {
            genObj = new GenericClass<float>();
            studentList = new List<Student>()
            {
                new Student(){ StudentID=101, Name="Alice",  Course=CourseType.CSE, Address = "Himachal"},
                new Student(){ StudentID=102, Name="Bob",  Course=CourseType.CSE,Address = "Chandigarh"},
                new Student(){ StudentID=103, Name="Charlie", Course=CourseType.CSE,Address = "Ludhiana"},
                new Student(){ StudentID=104, Name="Diana", Course=CourseType.CSE,Address = "Phagwara"},
                new Student(){ StudentID=105, Name="Ethan", Course=CourseType.CSE,Address = "Jalndhar"},
                new Student(){ StudentID=106, Name="Alice",  Course=CourseType.CSE, Address = "Alwar"},
                new Student(){ StudentID=107, Name="Bob",  Course=CourseType.CSE,Address = "Bumbloo"},
                new Student(){ StudentID=108, Name="Charlie", Course=CourseType.CSE,Address = "Barsar"},
                new Student(){ StudentID=109, Name="Diana", Course=CourseType.CSE,Address = "Mehre"},
                new Student(){ StudentID=110, Name="Ethan", Course=CourseType.CSE,Address = "Jhunjhunu"},
                new Student(){ StudentID=111, Name="Alice",  Course=CourseType.CSE, Address = "Pune"},
                new Student(){ StudentID=112, Name="Bob",  Course=CourseType.CSE,Address = "Coorg"},
                new Student(){ StudentID=113, Name="Charlie", Course=CourseType.CSE,Address = "Combtore"},
                new Student(){ StudentID=114, Name="Diana", Course=CourseType.CSE,Address = "Delhi"},
                new Student(){ StudentID=115, Name="Ethan", Course=CourseType.CSE,Address = "Una"},
                new Student(){ StudentID=116, Name="Alice",  Course=CourseType.CSE, Address = "mandi"},
                new Student(){ StudentID=117, Name="Bob",  Course=CourseType.CSE,Address = "Chandigarh"},
                new Student(){ StudentID=118, Name="Charlie", Course=CourseType.CSE,Address = "Ludhiana"},
                new Student(){ StudentID=119, Name="Diana", Course=CourseType.CSE,Address = "Phagwara"},
                new Student(){ StudentID=120, Name="Ethan", Course=CourseType.CSE,Address = "Jalndhar"}
            };
        }
        public bool DropStudentDetails(int id)
        {
            Student student = studentList.Find(s => s.StudentID == id);
            if(student == null)
            {
                throw new LPUException("Student Record Not Found........");
            }
            else
            {
                studentList.Remove(student);
                return true;
            }
            return false;
        }

        public bool EnrollStudent(Student sObj)
        {
            bool flag = false;
            if(sObj!=null)
            {
                studentList.Add(sObj);
                flag = true;
            }
            return flag;
        }

        public Student SearchStudentByID(int rollNo)
        {
            Student myStud = null;
            if (rollNo != 0)
            {
                myStud = studentList.Find(s => s.StudentID == rollNo);
                if(myStud == null)
                {
                    throw new LPUException("Student Record Not Found........");
                }
            }
            else
            {
                throw new LPUException("Error Generated........");
            }
            return myStud;
        }

        public List<Student> SearchStudentByName(string name)
        {

            List<Student> data = studentList.FindAll(d => d.Name == name);
            return data;

        }

        public bool UpdateStudentDetails(int id, Student newObj)
        {
            Student student = studentList.Find(s => s.StudentID == id);
            if(student == null)
            {
                throw new LPUException("Student Record Not Found........");
            }
            else if (student != null)
            {
                student.Name = newObj.Name;
                student.Course = newObj.Course;
                student.Address = newObj.Address;
                return true;
            }
            return false;
        }
    }
}
