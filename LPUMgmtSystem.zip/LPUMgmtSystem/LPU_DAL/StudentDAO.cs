﻿using System;
using System.Diagnostics;
using LPU_Common;
using LPU_Entity;
using LPU_Exception;
namespace LPU_DAL
{
    public class StudentDAO : IStudentCRUD
    {
        static List<Student> studentList;
        static StudentDAO()
        {
            studentList = new List<Student>()
            {
                new Student(){ StudentID=101, Name="Alice",  Course=CourseType.CSE, Address = "Himachal"},
                new Student(){ StudentID=102, Name="Bob",  Course=CourseType.CSE,Address = "Chandigarh"},
                new Student(){ StudentID=103, Name="Charlie", Course=CourseType.CSE,Address = "Ludhiana"},
                new Student(){ StudentID=104, Name="Diana", Course=CourseType.CSE,Address = "Phagwara"},
                new Student(){ StudentID=105, Name="Ethan", Course=CourseType.CSE,Address = "Jalndhar"}
            };
        }
        public bool DropStudentDetails(int id)
        {
            throw new NotImplementedException();
        }

        public bool EnrollStudent(Student sObj)
        {
            bool flag = false;
            if(sObj!=null)
            {
                studentList.Add(sObj);
                flag = true;
            }
            return flag;
        }

        public Student SearchStudentByID(int rollNo)
        {
            Student myStud = null;
            if (rollNo != 0)
            {
                myStud = studentList.Find(s => s.StudentID == rollNo);
                if(myStud == null)
                {
                    throw new LPUException("Student Record Not Found........");
                }
            }
            else
            {
                throw new LPUException("Error Generated........");
            }
            return myStud;
        }

        public List<Student> SearchStudentByName(string name)
        {
            List<Student> data = studentList.FindAll(d => d.Name == name);
            return data;

        }

        public bool UpdateStudentDetails(int id, Student newObj)
        {
            throw new NotImplementedException();
        }
    }
}
