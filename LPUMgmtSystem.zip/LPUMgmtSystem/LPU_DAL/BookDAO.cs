﻿using LPU_Common;
using LPU_Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace LPU_DAL
{
    public class BookDAO : IRepo<Book>
    {
        public bool AddDetails(Book obj)
        {
            throw new NotImplementedException();
        }

        public bool DeleteDetails(int id)
        {
            throw new NotImplementedException();
        }

        public List<Book> ShowAll()
        {
            throw new NotImplementedException();
        }

        public Book ShowDetailsByID(int id)
        {
            throw new NotImplementedException();
        }

        public bool UpdateDetails(int id, Book obj)
        {
            throw new NotImplementedException();
        }
    }
}
