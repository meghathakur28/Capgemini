﻿using LPU_Common;
using LPU_Entity;
using LPU_Exception;
using System;
using System.Collections.Generic;
using System.Text;

namespace LPU_DAL
{
    public class EmployeeDAO : IEmployee<Employee>
    {
        static List<Employee> empList;
        public EmployeeDAO()
        {
            empList = new List<Employee>();
            empList.Add(new Employee() { EmployeeId = 1, EmployeeName = "John", Age = 45, Gender = "Male", Address = "123 Main St", Salary = 60000 });
            empList.Add(new Employee() { EmployeeId = 2, EmployeeName = "Jane", Age = 38, Gender = "Female", Address = "456 Oak Ave", Salary = 75000 });
            empList.Add(new Employee() { EmployeeId = 3, EmployeeName = "Mike", Age = 50, Gender = "Male", Address = "789 Pine Rd", Salary = 80000 });
            empList.Add(new Employee() { EmployeeId = 4, EmployeeName = "Emily", Age = 29, Gender = "Female", Address = "321 Maple Ln", Salary = 55000 });
        }
        public bool AddDetails(Employee obj)
        {
            bool flag = false;
            if (obj != null)
            {
                empList.Add(obj);
                flag = true;
            }
            else
            {
                throw new LPUException("Employee Details are not valid");
            }
            return flag;
        }

        public bool DeleteDetails(int id)
        {
            if (id > 0)
            {
                Employee employee = empList.Find(e => e.EmployeeId == id);
                if (employee != null)
                {
                    empList.Remove(employee);
                    return true;
                }
                else
                {
                    throw new LPUException("Employee not found");
                }
            }
            else
            {
                throw new LPUException("Employee ID is not valid");
            }
            return false;
        }

        public List<Employee> ShowAll()
        {
            try
            {
                return empList;
            }
            catch (Exception ex)
            {
                throw new LPUException("There is some techincal glich. Sorry we r not able to show u the List of the employees");
            }
        }

        public List<Employee> ShowAllEmployeeWithAgeAbove40()
        {
            List<Employee> filteredList = new List<Employee>();
            foreach (var emp in empList)
            {
                if (emp.Age > 40)
                {
                    filteredList.Add(emp);
                }
            }
            return filteredList;
        }

        public List<Employee> ShowAllFemaleEmployee()
        {
            List<Employee> femaleEmployees = new List<Employee>();
            foreach (var emp in empList)
            {
                if (emp.Gender.Equals("Female"))
                {
                    femaleEmployees.Add(emp);
                }
            }
            return femaleEmployees;
        }

        public List<Employee> ShowAllMaleEmployee()
        {
            List<Employee> maleEmployees = new List<Employee>();
            foreach (var emp in empList)
            {
                if (emp.Gender.Equals("Male"))
                {
                    maleEmployees.Add(emp);
                }
            }
            return maleEmployees;
        }

        public Employee ShowDetailsByID(int id)
        {
            if (id > 0)
            {
                Employee employee = empList.Find(e => e.EmployeeId == id);
                if (employee != null)
                {
                    return employee;
                }
                else
                {
                    throw new LPUException("Employee not found");
                }
            }
            else
            {
                throw new LPUException("Employee ID is not valid");
            }
        }

        public bool UpdateDetails(int id, Employee obj)
        {
            if (id > 0 && obj != null)
            {
                Employee employee = empList.Find(e => e.EmployeeId == id);
                if (employee != null)
                {
                    employee = obj;
                    return true;
                }
                else
                {
                    throw new LPUException("Employee not found");
                }
            }
            else
            {
                throw new LPUException("Employee Details are not valid");
            }
            return false;
        }
           
    }
}
