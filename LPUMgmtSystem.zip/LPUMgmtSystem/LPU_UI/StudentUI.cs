﻿using System;
using System.Linq.Expressions;
using System.Xml.Serialization;
using LPU_BL;
using LPU_Entity;
using LPU_Exception;
namespace LPU_UI
{
    class StudnetUI
    {
        public static void Menu()
        {
            Console.WriteLine("\n         Student Management System        ");
            Console.WriteLine("========================================");
            Console.WriteLine("1. Search Student By ID ");
            Console.WriteLine("2. Search Student By Name");
            Console.WriteLine("3. Add Student Details");
            Console.WriteLine("4. Update Student Details ");
            Console.WriteLine("5. Drop Student Details ");
            Console.WriteLine("6. Exit ");
        }
        public static void StudentMain()
        {
            StudentBL sblObj = new StudentBL();
            int choice = 0;
            while (choice!=6)
            {
                Menu();
                Console.WriteLine("Please enter your choice: ");
                choice = Int32.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1: // search student by id 
                        {
                            int id = 0;
                            try
                            {
                                Console.WriteLine("\n Enter Student ID for Search: ");
                                id = Int32.Parse(Console.ReadLine());

                                Student sObj = sblObj.SearchStudentByID(id);
                                if (sObj != null)
                                {
                                    Console.ForegroundColor = ConsoleColor.Magenta;
                                    Console.WriteLine("ID\t |Name\t | Course\t |Address");
                                    Console.WriteLine("===================================");
                                    Console.WriteLine($"{sObj.StudentID}\t| {sObj.Name}\t| {sObj.Course}\t | {sObj.Address}");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                            }
                            catch (LPUException e)
                            {
                                Console.WriteLine(e.Message);
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e.Message);
                            }
                            break;
                        }
                    case 2: //search student by name
                        {
                            try
                            {
                                Console.WriteLine("\n Enter Student Name for Search: ");
                                string name = Console.ReadLine();
                                List<Student> stdList = sblObj.SearchStudentByName(name);
                                Console.ForegroundColor = ConsoleColor.Magenta;
                                Console.WriteLine("ID\t |Name\t | Course\t |Address");
                                Console.WriteLine("===================================");
                                foreach (var i in stdList)
                                {
                                    Console.WriteLine($"{i.StudentID}\t| {i.Name}\t| {i.Course}\t | {i.Address}");
                                }
                                Console.ForegroundColor = ConsoleColor.White;
                            }
                            catch (LPUException e)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("Enable to find");
                                Console.ForegroundColor = ConsoleColor.White;
                            }
                            catch (Exception e)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("We are going in a construction .. sorry foe the intruption");
                                Console.ForegroundColor = ConsoleColor.White;
                            }
                            break;
                        }
                    case 3://add students
                        {
                            Student sObj = new Student();
                            Console.WriteLine("\n Enter Student Details: ");
                            Console.Write("Enter Student ID: ");
                            sObj.StudentID = Int32.Parse(Console.ReadLine());
                            Console.Write("Enter Student Name: ");
                            sObj.Name = Console.ReadLine();
                            Console.Write("Enter Student Address: ");
                            sObj.Address = Console.ReadLine();
                            Console.Write("Enter Course Type: ");
                            sObj.Course = (CourseType)Enum.Parse(typeof(CourseType), Console.ReadLine(), true);
                            try
                            {
                                bool ans = sblObj.EnrollStudent(sObj);
                                if (ans)
                                {
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine("Student Enrolled Successfully");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                            }
                            catch (LPUException e)
                            {
                                Console.WriteLine(e.Message);
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e.Message);
                            }
                            break;
                        }
                    case 4: // modify studnet details
                        {
                            Console.WriteLine("\n Enter Student ID for Update: ");
                            int id = Int32.Parse(Console.ReadLine());
                            Student sObj = new Student();
                            Console.WriteLine("\n Enter New Student Details: ");
                            Console.Write("Enter Student Name: ");
                            sObj.Name = Console.ReadLine();
                            Console.Write("Enter Student Address: ");
                            sObj.Address = Console.ReadLine();
                            Console.Write("Enter Course Type: ");
                            sObj.Course = (CourseType)Enum.Parse(typeof(CourseType), Console.ReadLine(), true);
                            try
                            {
                                bool ans = sblObj.UpdateStudentDetails(id, sObj);
                                if (ans)
                                {
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine("Student Details Updated Successfully");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                                else {
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine("Student Details Updation Failed");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                            }
                            catch (LPUException e)
                            {
                                Console.WriteLine(e.Message);
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e.Message);
                            }
                            break;
                        }
                    case 5: // drop 
                        {
                            Student sObj  = new Student();
                            Console.WriteLine("\n Enter Student ID for Drop: ");
                            int id = Int32.Parse(Console.ReadLine());
                            try
                            {
                                bool ans = sblObj.DropStudentDetails(id);
                                if (ans)
                                {
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine("Student Dropped Successfully");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine("Student Drop Failed");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                                break;
                            }
                            catch (LPUException e)
                            {
                                Console.WriteLine(e.Message);
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e.Message);
                            }
                            break;
                        }
                    case 6: // exit
                        {
                            Console.WriteLine("Thank you for using Student Management System. Goodbye!");
                            break;
                        }
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }
    }
}