﻿using System;
using System.Linq.Expressions;
using System.Xml.Serialization;
using LPU_BL;
using LPU_Entity;
using LPU_Exception;
namespace LPU_UI
{
    class Program
    {
        public static void Menu()
        {
            Console.WriteLine("         LPU Management System        ");
            Console.WriteLine("========================================");
            Console.WriteLine("1. Student");
            Console.WriteLine("2. Employee");
            Console.WriteLine("3. Book");
            Console.WriteLine("4. Exit ");
        }
        public static void Main(string[] args)
        {

            int choice = 0;
            while(choice!=4)
            {
                Menu();
                Console.WriteLine("Enter your choice:");
                choice = Int32.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        {
                            StudnetUI.StudentMain();
                            break;
                        }
                    case 2:
                        {
                            EmployeeUI.FacultyMain();
                            break;
                        }
                    case 3:
                        {
                            BookUI.BookMain();
                            break;
                        }
                    case 4:
                        {
                            Console.WriteLine("Exiting the application. Goodbye!");
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Invalid choice. Please try again.");
                            break;
                        }
                }
            }
        }
    }
}