﻿using LPU_BL;
using LPU_Entity;
using LPU_Exception;
using System;
using System.Collections.Generic;
using System.Text;

namespace LPU_UI
{
    public class EmployeeUI
    {
        public static void Menu()
        {
            Console.WriteLine("         Faculty Management System        ");
            Console.WriteLine("========================================");
            Console.WriteLine("1. Add Faculty");
            Console.WriteLine("2. Delete Faculty");
            Console.WriteLine("3. Show All Faculties");
            Console.WriteLine("4. Show Faculty By ID");
            Console.WriteLine("5. Update Faculty Details");
            Console.WriteLine("6. Show Employees With Age Above 40");
            Console.WriteLine("7. Show All Male Employees");
            Console.WriteLine("8. Show All Female Employees");
            Console.WriteLine("9. Exit");
        }
        public static void FacultyMain()
        {
            EmployeeBL employeeBL = new EmployeeBL();
            int choice = 0;
            while (choice != 9)
            {
                Menu();
                Console.WriteLine("Enter your choice:");
                choice = Int32.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        {
                            Employee employee = new Employee();
                            Console.WriteLine("Enter Faculty ID:");
                            employee.EmployeeId = Int32.Parse(Console.ReadLine());
                            Console.WriteLine("Enter Faculty Name:");
                            employee.EmployeeName = Console.ReadLine();
                            Console.WriteLine("Enter Faculty Age:");
                            employee.Age = Int32.Parse(Console.ReadLine());
                            Console.WriteLine("Enter the gender:");
                            employee.Gender = Console.ReadLine();
                            Console.WriteLine("Enter Faculty Address:");
                            employee.Address = Console.ReadLine();
                            Console.WriteLine("Enter Faculty Salary:");
                            employee.Salary = Double.Parse(Console.ReadLine());
                            try
                            {

                                bool ans = employeeBL.AddDetails(employee);
                                if (ans)
                                {
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine("Faculty added successfully.");
                                    Console.ResetColor();
                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine("Failed to add faculty.");
                                    Console.ResetColor();
                                }
                            }
                            catch (LPUException ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                            break;
                        }
                    case 2:
                        {
                            Console.WriteLine("Enter Faculty ID to delete:");
                            int id = Int32.Parse(Console.ReadLine());
                            try
                            {
                                bool ans = employeeBL.DeleteDetails(id);
                                if (ans)
                                {
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine("Faculty deleted successfully.");
                                    Console.ResetColor();
                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine("Failed to delete faculty.");
                                    Console.ResetColor();
                                }
                            }
                            catch (LPUException ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                            break;
                        }
                    case 3:
                        {
                            Console.WriteLine("List of All Employees:");
                            try
                            {
                                List<Employee> employees = employeeBL.ShowAll();
                                foreach (Employee emp in employees)
                                {
                                    Console.WriteLine($"ID: {emp.EmployeeId}, Name: {emp.EmployeeName}, Age: {emp.Age}, Gender: {emp.Gender}, Address:{emp.Address}, Salary: {emp.Salary}");
                                }
                            }
                            catch (LPUException ex)
                            {
                                Console.WriteLine(ex.Message); 
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                                break;
                        }
                    case 4:
                        {

                            Console.WriteLine("Enter Faculty ID to view details:");
                            int id = Int32.Parse(Console.ReadLine());
                            try
                            {
                                Employee emp = employeeBL.ShowDetailsByID(id);
                                if (emp != null)
                                {
                                    Console.WriteLine($"ID: {emp.EmployeeId}, Name: {emp.EmployeeName}, Age: {emp.Age}, Gender: {emp.Gender}, Address:{emp.Address}, Salary: {emp.Salary}");
                                }
                            }
                            catch (LPUException ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                                break;
                        }
                    case 5:
                        {
                            Console.WriteLine("Enter Faculty ID to update:");
                            int id = Int32.Parse(Console.ReadLine());
                            Employee updatedEmployee = new Employee();
                            Console.WriteLine("Enter new Faculty Name:");
                            updatedEmployee.EmployeeName = Console.ReadLine();
                            Console.WriteLine("Enter new Faculty Age:");
                            updatedEmployee.Age = Int32.Parse(Console.ReadLine());
                            Console.WriteLine(" Enter the gender");
                            updatedEmployee.Gender = Console.ReadLine();
                            Console.WriteLine("Enter new Faculty Address:");
                            updatedEmployee.Address = Console.ReadLine();
                            Console.WriteLine("Enter new Faculty Salary:");
                            updatedEmployee.Salary = Double.Parse(Console.ReadLine());
                            try
                            {
                                bool ans = employeeBL.UpdateDetails(id, updatedEmployee);
                                if (ans)
                                {
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine("Faculty updated successfully.");
                                    Console.ResetColor();
                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine("Failed to update faculty.");
                                    Console.ResetColor();
                                }
                            }
                            catch (LPUException ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                            break;
                        }
                    case 6:
                        {
                            List<Employee> employeesAbove40 = employeeBL.ShowAllEmployeeWithAgeAbove40();
                            try
                            {
                                if (employeesAbove40.Count > 0)
                                {
                                    Console.WriteLine("Employees with age above 40:");
                                    Console.ForegroundColor = ConsoleColor.Yellow;
                                    foreach (Employee emp in employeesAbove40)
                                    {
                                        Console.WriteLine($"ID: {emp.EmployeeId}, Name: {emp.EmployeeName}, Age: {emp.Age}, Gender: {emp.Gender}, Address:{emp.Address}, Salary: {emp.Salary}");
                                    }
                                    Console.ResetColor();
                                }
                                else
                                {
                                    Console.WriteLine("No employees found with age above 40.");
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.Message);
                            }

                            break;
                        }
                    case 7:
                        {
                            List<Employee> maleEmp = employeeBL.ShowAllMaleEmployee();
                            try
                            {
                                if (maleEmp.Count > 0)
                                {

                                    Console.WriteLine("List of Male Employees:");
                                    Console.ForegroundColor = ConsoleColor.Yellow;
                                    foreach (Employee maleEmployees in maleEmp)
                                    {
                                        Console.WriteLine($"ID: {maleEmployees.EmployeeId}, Name: {maleEmployees.EmployeeName}, Age: {maleEmployees.Age}, Gender: {maleEmployees.Gender}, Address:{maleEmployees.Address}, Salary: {maleEmployees.Salary}");
                                    }
                                    Console.ResetColor();
                                }
                                else
                                {
                                    Console.WriteLine("No male employees found.");
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                                    break;
                        }
                    case 8:
                        {
                            List<Employee> femaleEmp = employeeBL.ShowAllFemaleEmployee();
                            try
                            {
                                if (femaleEmp.Count > 0)
                                {
                                    Console.WriteLine("List of Female Employees:");
                                    Console.ForegroundColor = ConsoleColor.Yellow;
                                    foreach (Employee femaleEmployees in femaleEmp)
                                    {
                                        Console.WriteLine($"ID: {femaleEmployees.EmployeeId}, Name: {femaleEmployees.EmployeeName}, Age: {femaleEmployees.Age}, Gender: {femaleEmployees.Gender}, Address:{femaleEmployees.Address}, Salary: {femaleEmployees.Salary}");
                                    }
                                    Console.ResetColor();
                                }
                                else
                                {
                                    Console.WriteLine("No male employees found.");
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                            break;
                        }
                    case 9:
                        {
                            Console.WriteLine("Exiting Faculty Management System. Goodbye!");
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Invalid choice. Please try again.");
                            break;
                        }
                }
            }
        }
    }
}
