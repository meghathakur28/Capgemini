﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LPU_UI
{
    public  class BookUI
    {

        public static void BookMain()
        {
            Console.WriteLine("Welcome to the Book Management Section.");
            // Further implementation goes here
        }
    }
}
