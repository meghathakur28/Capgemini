using System;
namespace MegaMart
{
    public class ValidatePricePerUnitException : Exception
    {
        public ValidatePricePerUnitException(string message) : base(message)
        {
        }
    }
}