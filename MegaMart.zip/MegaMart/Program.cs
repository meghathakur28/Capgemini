﻿using MegaMart;
class Program
{
    static void Main(string[] args)
    {
        OrderBL orderBL = new OrderBL();
        orderBL.Menu();
    }
}
