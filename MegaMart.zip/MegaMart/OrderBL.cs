using System;
using System.Collections.Generic;
namespace MegaMart
{
    public class  OrderBL
    {
        List<Order> Orders;
        public OrderBL()
        {
            Orders = new List<Order>();
        }
        public void Menu()
        {
            int choice = 0;
            while(choice!=6)
            {
                Console.WriteLine("*************Menu************");
                Console.WriteLine("1. Place New Order");
                Console.WriteLine("2. View All Order");
                Console.WriteLine("3. View Orders by Category");
                Console.WriteLine("4. View High Value Orders (Final Amount >= 10,000 ");
                Console.WriteLine("5. Total Revenue Generated");
                Console.WriteLine("6. Exit");
                Console.WriteLine("Enter your choice:");
                choice = Int32.Parse(Console.ReadLine());
                switch(choice)
                {
                    case 1:
                        {
                            PlaceNewOrder();
                            break;
                        }
                    case 2:
                        {
                            ViewAllOrders();
                            break;
                        }
                    case 3:
                        {
                            ViewOrdersByCategory();
                            break;
                        }
                    case 4:
                        {
                            ViewHighValueOrders();
                            break;
                        }
                    case 5:
                        {
                            TotalRevenueGenerated();
                            break;
                        }
                    case 6:
                        {
                            Console.WriteLine("Exiting the application.");
                            break;
                        }
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }

        protected void PlaceNewOrder()
        {
            Console.WriteLine("Placing a new order...\n");

            Order newOrder = new Order();
            Console.WriteLine("Enter Order ID: ");
            newOrder.OrderID = Console.ReadLine();

            Console.WriteLine("Enter the Customer Name: ");
            newOrder.CustomerName = Console.ReadLine();
            Console.WriteLine("Enter Product Category (1-Electronics, 2-Clothing, 3-Groceries): ");
            int productCategory = Int32.Parse(Console.ReadLine());
            while (productCategory<1 || productCategory > 3)
            {
                Console.WriteLine("Invalid Product Category. Order placement failed.\n");
                Console.WriteLine("Enter Product Category (1-Electronics, 2-Clothing, 3-Groceries): ");
                productCategory = Int32.Parse(Console.ReadLine());
            }
            newOrder.ProductCategory = productCategory;
            switch (productCategory)
            {
                case 1:
                    {
                        newOrder.ProductCategoryName = "Electronics";
                        break;
                    }
                case 2:
                    {
                        newOrder.ProductCategoryName = "Fashion";
                        break;
                    }
                case 3:
                    {
                        newOrder.ProductCategoryName = "Home Applicances";
                        break;
                    }
            }
            Console.WriteLine("Enter Product Name: ");
            newOrder.ProductName = Console.ReadLine();

            Console.WriteLine("Enter Quantity: ");
            int quantity = Int32.Parse(Console.ReadLine());

            try
            {
                if (quantity < 0)
                {
                    throw new ValidateQuantityException("Quantity must be greater than 0");
                }
                else
                {
                    newOrder.Quantity = quantity;
                }
            }
            catch (ValidateQuantityException ex)
            {
                Console.WriteLine(ex.Message);
                return;
            }

            Console.WriteLine("Enter Price per Unit: ");
            double pricePerUnit = Double.Parse(Console.ReadLine());

            try
            {
                if (pricePerUnit < 0)
                {
                    throw new ValidatePricePerUnitException("Price Per Unit must be greater than 0");
                }
                else
                {
                    newOrder.PricePerUnit = pricePerUnit;
                }
            }
            catch (ValidatePricePerUnitException ex)
            {
                Console.WriteLine(ex.Message);
                return;
            }

            Console.WriteLine("Enter Payment Mode (1-Credit Card, 2-Debit Card, 3-Cash): ");
            int paymentMode = Int32.Parse(Console.ReadLine());
            while(paymentMode < 1 || paymentMode > 3)
            {
                Console.WriteLine("Invalid Payment Mode. Order placement failed.\n");
                Console.WriteLine("Enter Payment Mode (1-Credit Card, 2-Debit Card, 3-Cash): ");
                paymentMode = Int32.Parse(Console.ReadLine());

            }
            newOrder.PaymentMode = paymentMode;
            Orders.Add(newOrder);
            Console.WriteLine("Order placed successfully!\n");
        }
        protected void ViewAllOrders()
        {
            Console.WriteLine("Viewing all orders...\n");
            foreach(var order in Orders)
            {
                Console.WriteLine($"Order ID: {order.OrderID}, Customer Name: {order.CustomerName}, Product Category: {order.ProductCategory}, Product Name: {order.ProductName}, Quantity: {order.Quantity}, Price per Unit: {order.PricePerUnit}");
            }
            Console.WriteLine();
        }
        protected void ViewOrdersByCategory()
        {
            Console.WriteLine("Enter Product Category Name");
            string category = Console.ReadLine();

            List<Order> custOrder = Orders.FindAll(d => d.ProductCategoryName == category);
            Console.WriteLine("Here is the List: ");
            if(custOrder != null)
            {
                foreach(var i in custOrder)
                {
                    Console.WriteLine("Order ID: " + i.OrderID);
                    Console.WriteLine("Customer Name: " + i.CustomerName);
                    Console.WriteLine("Product Category " + i.ProductCategoryName);
                    Console.WriteLine("Product Name: " + i.ProductName);
                    Console.WriteLine("Order Amount: " + i.OrderAmount);
                    Console.WriteLine("Discount Applied: "+ i.DiscountAmount);
                    Console.WriteLine("Delivery Charge: " + i.DeliveryCharge) ;
                    Console.WriteLine("Final Payable Amount: "+i.FinalPayableAmount);
                    Console.WriteLine("Order Status: "+i.OrderStatus);
                }
            }
            else
            {
                Console.WriteLine("Not Found");
            }

        }
        protected void ViewHighValueOrders()
        {
            List<Order> custOrder = Orders.FindAll(d => d.FinalPayableAmount >= 10000);
            if (custOrder != null)
            {
                foreach (var i in custOrder)
                {
                    Console.WriteLine("Order ID: " + i.OrderID);
                    Console.WriteLine("Customer Name: " + i.CustomerName);
                    Console.WriteLine("Product Category " + i.ProductCategoryName);
                    Console.WriteLine("Product Name: " + i.ProductName);
                    Console.WriteLine("Order Amount: " + i.OrderAmount);
                    Console.WriteLine("Discount Applied: " + i.DiscountAmount);
                    Console.WriteLine("Delivery Charge: " + i.DeliveryCharge);
                    Console.WriteLine("Final Payable Amount: " + i.FinalPayableAmount);
                    Console.WriteLine("Order Status: " + i.OrderStatus);
                }
            }
        }
        protected void TotalRevenueGenerated()
        {
            double sum = 0;
            foreach(var i in Orders)
            {
                sum += i.FinalPayableAmount;
            }
            Console.WriteLine("Total Revenue is: " + sum);
        }
    }
}