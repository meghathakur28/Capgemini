using System;
namespace MegaMart
{
    public class Order
    {
        public string OrderID { get; set; }
        public string CustomerName { get; set; }
        public int ProductCategory { get; set; }
        public string ProductCategoryName { get; set; }
        public string ProductName { get; set; }
        public int Quantity { get; set; }
        public double PricePerUnit { get; set; }
        public int PaymentMode { get; set; }
        public double OrderAmount {
            get { return Quantity * PricePerUnit; }
        }
        public double DiscountAmount
        {
            get
            {
                if (PaymentMode == 2 || PaymentMode == 3)
                {
                    if (OrderAmount >= 5000) {
                        if (ProductCategory == 1) return 15;
                        else if (ProductCategory == 2) return 10;
                        else return 13;
                    }
                    else
                    {
                        if (ProductCategory == 1) return 10;
                        else if (ProductCategory == 2) return 5;
                    else return 8;
                    }
                }
                else
                {
                    if (ProductCategory == 1) return 10;
                    else if (ProductCategory == 2) return 5;
                    else  return 8;
                }
            }
        }
        public double DeliveryCharge { 
            get 
            {
                if (OrderAmount >= 10000) return 0;
                else if (OrderAmount >= 5000 && OrderAmount < 10000) return 50;
                return 100;
            }
        }
        public double FinalPayableAmount
        {
            get
            {
                return OrderAmount - (OrderAmount * DiscountAmount / 100) + DeliveryCharge;
            }
        }
        public string OrderStatus { 
            get { 
                if(FinalPayableAmount >= 15000) return "Priority Delivery";
                else return "Standard Delivery";
            } 
        }
    }
}
