using System;
namespace MegaMart
{
    public class ValidateQuantityException : Exception
    {
        public ValidateQuantityException(string message) : base(message)
        {
        }
    }
}