using System;
namespace TravelTicketBooking
{
    public class Passenger
    {
        public int PassengerID { get; set; }
        public string PassengerName { get; set; }
        int age;
        public int Age
        {
            get
            {
                return age;
            }
            set
            {
                if (value <= 5 && value > 0)
                {
                    throw new FreeBookingException("Free Tickte - No Booking Required");
                }
                else if (value > 80)
                {
                    throw new MedicalException("Medical clearance Required");
                }
                else
                {
                    age = value;
                }

            }
        }
        public int TravelType { get; set; }
        public double BaseFare { get; set; }
        public bool GovermentEmployee { get; set; }
    }
}