using System;
namespace TravelTicketBooking
{
    public class FreeBookingException : Exception
    {
        public FreeBookingException() { }
       public FreeBookingException(string message) : base(message)
       {

        }
    }
}