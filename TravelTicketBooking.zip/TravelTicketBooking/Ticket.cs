using System;
namespace TravelTicketBooking
{
    public class Ticket : Passenger
    {
        double FareAfterClass;
        public string ClassType;
        private void FlightTicketBooking()
        {
            Console.WriteLine("Class Selection: 1) Economy 2) Business");
            int typeOfClass = Int32.Parse(Console.ReadLine());
            switch (typeOfClass)
            {
                case 1:
                    {
                        Console.WriteLine("Economy Class Selected");
                        ClassType = "Economy";
                        FareAfterClass = BaseFare * 2.5;
                        break;
                    }
                case 2:
                    {
                        Console.WriteLine("Business Class Selected");
                        ClassType = "Business";
                        FareAfterClass = BaseFare * 3.5;
                        break;
                    }

            }
        }
        private void TrainTicketBooking()
        {
            Console.WriteLine("Class Selection: 1) General 2) Sleeper 3) AC");
            int typeOfClass = Int32.Parse(Console.ReadLine());
            switch (typeOfClass)
            {
                case 1:
                    {
                        Console.WriteLine("General Class Selected");
                        ClassType = "General";
                        FareAfterClass = BaseFare * 1.0;
                        break;
                    }
                case 2:
                    {
                        Console.WriteLine("Sleeper Class Selected");
                        ClassType = "Sleeper";
                        FareAfterClass = BaseFare * 1.3;
                        break;
                    }
                case 3:
                    {                        
                        Console.WriteLine("AC Class Selected");
                        ClassType = "AC";
                        FareAfterClass = BaseFare * 1.6;
                        break;
                    }

            }
        }
        private void BusTicketBooking()
        {
            Console.WriteLine("Class Selection: 1) Sleeper 2) Seater");
            int typeOfClass = Int32.Parse(Console.ReadLine());
            switch (typeOfClass)
            {
                case 1:
                    {
                        Console.WriteLine("Sleeper Class Selected");
                        ClassType = "Sleeper";
                        FareAfterClass = BaseFare * 1.2;
                        break;
                    }
                case 2:
                    {
                        Console.WriteLine("Seater Class Selected");
                        ClassType = "Seater";
                        FareAfterClass = BaseFare * 1.0;
                        break;
                    }

            }

        }

        public void BookingTicket()
        {
            switch (TravelType)
            {
                case 1:
                    {
                        BusTicketBooking();
                        break;
                    }
                case 2:
                    {
                        TrainTicketBooking();
                        break;
                    }
                case 3:
                    {
                        FlightTicketBooking();
                        break;
                    }
                default:
                    {
                        Console.WriteLine("Invalid Travel Type");
                        break;
                    }
            }
        }
        public double DiscountAmount()
        {
            double fare = FareAfterClass;
            if (Age>=60)
            {
                return fare * 30 / 100;
            }
            else if(GovermentEmployee)
            {
                return fare * 15 / 100;
            }
            else if(Age>5&&Age<=12)
            {
                return fare * 50 / 100;
            }
            else
            {
                return 0;
            }
        }
        public double TotalFare()
        {
            return FareAfterClass - DiscountAmount();
        }
        public void BookingStatus()
        {
            if(TotalFare()>=10000)
            {
                if (TravelType == 3)
                {
                    Console.WriteLine("Status : Booking Confirmed");

                }
                else
                {
                    Console.WriteLine("Status : Waiting List");
                }
            }
            else
            {
                Console.WriteLine("Status : Booking Confirmed");
            }
        }


    }

}