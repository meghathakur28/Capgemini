﻿// See https://aka.ms/new-console-template for more information
using TravelTicketBooking;
public class Program
{
    public static void Main(string[] args)
    {
        Ticket tObj = new Ticket();
        Console.WriteLine("Welcome to Travel Ticket Booking System");

        Console.WriteLine("Enter the passenger ID: ");
        tObj.PassengerID = Int32.Parse(Console.ReadLine());

        Console.WriteLine("Enter the passenger name: ");
        tObj.PassengerName = Console.ReadLine();

        Console.WriteLine("Enter the age: ");
        tObj.Age = Int32.Parse(Console.ReadLine());

        Console.WriteLine("Enter the travel type 1) Bus 2) Train 3) Flight");
        tObj.TravelType = Int32.Parse(Console.ReadLine());

        Console.WriteLine("Enter the base Price: ");
        tObj.BaseFare = Int32.Parse(Console.ReadLine());

        tObj.BookingTicket();

        Console.WriteLine("************  HERE IS YOUR TICKET  *************\n\n");

        Console.WriteLine("Passenger ID: " + tObj.PassengerID);
        Console.WriteLine("Name: " + tObj.PassengerName);
        Console.WriteLine("TravelType: " + tObj.TravelType);
        Console.WriteLine("Class: " + tObj.ClassType);
        Console.WriteLine("base Price: " + tObj.BaseFare);
        Console.WriteLine("FinalFare: "+ tObj.TotalFare());
        Console.WriteLine("Discount Applied: "+ tObj.DiscountAmount());
        tObj.BookingStatus();


    }
}
