using System;
namespace TravelTicketBooking
{
    public class MedicalException : Exception
    {
        public MedicalException() { }
       public MedicalException(string message) : base(message)
        {
        }
    }
}